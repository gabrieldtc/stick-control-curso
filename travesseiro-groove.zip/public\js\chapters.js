// ============ CHAPTERS JS ============

let currentChapterId = 0;
let chapterDataCache = null;
let cachedProgress = null;

// Get chapter from URL
const urlParams = new URLSearchParams(window.location.search);
const chapterParam = urlParams.get('cap');
if (chapterParam) {
  currentChapterId = parseInt(chapterParam);
}

// Chapter titles for navigation (all 51 chapters)
const chapterTitles = [
  "Introdução ao Stick Control",
  "Anatomia da Bateria",
  "Notação Básica",
  "Alternância Simples",
  "Pares (RR LL)",
  "Alternância com Acento",
  "Grupos de 3",
  "Quadrupletas",
  "Duplos",
  "Triplos",
  "Quádruplos",
  "Par e Ímpar",
  "Sincopa Básica",
  "Paradiddle Básico",
  "Paradiddle Duplo",
  "Paradiddle Triplo",
  "Flam Básico",
  "Flam com Duplos",
  "Drag Básico",
  "Ruff",
  "Buzz Rulo",
  "Open Rulo",
  "Single Stroke Rulo",
  "Double Stroke Rulo",
  "Five Stroke Rulo",
  "Seven Stroke Rulo",
  "Nine Stroke Rulo",
  "Ten Stroke Rulo",
  "Eleven Stroke Rulo",
  "Thirteen Stroke Rulo",
  "Fifteen Stroke Rulo",
  "Sincopação com Pares",
  "Acento na Segunda Batida",
  "Acento na Terceira Batida",
  "Acento na Quarta Batida",
  "Acento Duplo",
  "Acentos em Tercinas",
  "Sincopa de Rock",
  "Sincopa de Funk",
  "Sincopa de Bossa Nova",
  "Sincopa de Samba",
  "Grupos de 5",
  "Grupos de 7",
  "Grupos de 9",
  "Polirritmia 3x4",
  "Polirritmia 4x3",
  "Combinação Avançada 1",
  "Combinação Avançada 2",
  "Viradas Básicas",
  "Viradas Avançadas",
  "Exercício Final",
  "Exercícios de Pés",
  "Coordenação Mãos + Pés",
  "Dinâmica — Crescendo e Diminuendo",
  "Velocidade Gradual",
  "Grooves Aplicados",
  "Leitura de Partitura"
];

// Concept texts for each chapter
const chapterConcepts = {
  0: `<p>O <strong>Stick Control</strong> de George Lawrence Stone é considerado o livro mais importante para aprendizado de técnica de baquetas.</p><p>Publicado em 1935, ele ensina o controle total das mãos através de exercícios progressivos.</p><p>Neste curso, vamos transformar cada página em uma lição prática e fácil de entender.</p>`,
  1: `<p>A bateria é composta por vários componentes:</p><ul><li><strong>Bumbo (Bass Drum):</strong> O maior tambor, tocado com o pé</li><li><strong>Caixa (Snare):</strong> Tambor principal</li><li><strong>Tom (Tom):</strong> Tambores de diferentes alturas</li><li><strong>Chimbal (Hi-hat):</strong> Dois pratos que se fecham com pedal</li><li><strong>Pratos (Cymbals):</strong> Prato de ataque e de corte</li></ul>`,
  2: `<p>Na partitura de bateria:</p><ul><li><strong>♩ Nota preta:</strong> Uma batida (quarter note)</li><li><strong>♪ Nota com rabo:</strong> Meia batida (eighth note)</li><li><strong>Número do compasso:</strong> Quantas batidas por compasso</li></ul><p>Exemplo: <strong>4/4</strong> significa 4 batidas por compasso</p>`,
  3: `<p>O exercício de alternância simples é a base de tudo.</p><p>Você troca constantemente entre mão direita e esquerda.</p><p>O segredo é: <strong>DEVAGAR É RÁPIDO</strong></p>`,
  4: `<p>O padrão de pares é <strong>RR LL RR LL</strong></p><p>Cada mão toca duas vezes seguidas antes de trocar.</p><p>Isso treina a coordenação e a força de cada mão individualmente.</p>`,
  5: `<p>Acentuar significa tocar uma nota mais forte que as outras.</p><p>Isso dá energia e direção ao ritmo.</p><p>Pratique alternando entre notas fortes e fracas.</p>`,
  6: `<p>Grupos de 3 criam um efeito circular.</p><p>É como contar 'UNA-dois-tres, UNA-dois-tres'.</p><p>Isso desenvolve fluidez e coordenação.</p>`,
  7: `<p>Quadrupletas são 4 notas iguais no espaço de uma batida.</p><p>Com acento na primeira, fica 'TA-ta-ta-ta'.</p><p>É usada em fills e transições.</p>`,
  8: `<p>Duplos (RR LL) são usados em fills e transições.</p><p>É uma habilidade essencial para bateristas.</p><p>Pratique cada mão separadamente.</p>`,
  9: `<p>Triplos (RRR LLL) aparecem em patterns de rock e metal.</p><p>Exigem controle e resistência.</p><p>Comece devagar e aumente a velocidade.</p>`,
  10: `<p>Quádruplos (RRRR LLLL) são usados em fills rápidos e solos.</p><p>Desenvolvem resistência muscular.</p><p>Mantenha os punhos soltos.</p>`,
  11: `<p>Alternar grupos pares e ímpares cria ritmos interessantes.</p><p>Desenvolve coordenação avançada.</p><p>É a base para padrões complexos.</p>`,
  12: `<p>Sincopa é quando acentuamos a parte fraca do compasso.</p><p>Isso cria movimento e energia na música.</p><p>É fundamental para funk, jazz e bossa nova.</p>`,
  13: `<p>O paradiddle é um dos padrões mais importantes da bateria.</p><p>Combina alternância com duplos: <strong>R L R R L R L L</strong></p><p>Use em fills, grooves e solos.</p>`,
  14: `<p>O paradiddle duplo tem quatro notas alternadas e um duplo.</p><p>Padrão: <strong>R L R L R R L R L R L L</strong></p><p>Repare nos grupos: RLRL RR | LRLR LL.</p>`,
  15: `<p>O paradiddle triplo tem seis notas alternadas e um duplo.</p><p>Padrão: <strong>R L R L R L R R L R L R L R L L</strong></p><p>Grupos: RLRLRL RR | LRLRLR LL.</p>`,
  16: `<p>Um flam é duas batidas muito próximas.</p><p>A mão menor toca primeiro, seguida pela mão maior.</p><p>Cria um som mais 'gordo' e expressivo.</p>`,
  17: `<p>Combinar flams com duplos cria padrões mais complexos.</p><p>Manter fluidez nas transições é essencial.</p><p>Pratique lentamente primeiro.</p>`,
  18: `<p>O drag é um ornamento com duas notas rápidas antes da batida.</p><p>Cria um efeito de 'arrasto'.</p><p>É usado em estilos como blues e jazz.</p>`,
  19: `<p>O ruff é um ornamento com três notas rápidas.</p><p>Similar ao drag, mas com mais notas.</p><p>Cria um efeito mais dramático.</p>`,
  20: `<p>O buzz roll cria um som sustentado.</p><p>Usa múltiplos bounces rápidos da baqueta.</p><p>É usado em baladas e peças orquestrais.</p>`,
  21: `<h3>O que é um Open Roll?</h3><p>O open roll é um rulo tocado <span class='highlight'>aberto</span>: cada batida soa individual e claramente audível, ao contrário do buzz roll (som contínuo).</p><h3>Como Funciona</h3><div class='pattern-example'>RR LL RR LL<br>(dois golpes por mão, cada um nítido)</div><p>Cada mão toca <span class='highlight'>dois golpes seguidos</span>. O segundo golpe vem do <strong>rebote</strong> da baqueta, controlado para quicar uma vez só.</p><h3>Como Tocar</h3><ul><li><strong>1º golpe:</strong> pulso, deixando a baqueta subir naturalmente.</li><li><strong>2º golpe:</strong> aproveite o rebote e freie o movimento depois, para não quicar uma 3ª vez.</li><li><strong>Alternância:</strong> RR LL RR LL com o mesmo volume nas duas notas.</li></ul>`,
  22: `<p>O single stroke roll é a alternância mais rápida possível.</p><p>Padrão: <strong>R L R L R L...</strong></p><p>Desenvolve velocidade e resistência.</p>`,
  23: `<h3>O que é um Double Stroke Roll?</h3><p>É um rulo onde <span class='highlight'>cada mão toca duas batidas seguidas</span>: RR LL RR LL RR LL...</p><p>É a base de quase todos os rulos (five, seven, nine stroke) e dos fills.</p><h3>Como Funciona</h3><div class='pattern-example'>RR LL RR LL<br>(duas batidas em cada mão)</div><p>As <span class='highlight'>duas notas de cada mão devem soar com o mesmo volume e na mesma velocidade</span>.</p><h3>Como Tocar</h3><ul><li><strong>1º golpe:</strong> toque com o pulso.</li><li><strong>2º golpe:</strong> aproveite o rebote, ou dê um segundo golpe de pulso — sempre com o <strong>mesmo volume</strong> do 1º.</li><li><strong>Alternância:</strong> RR LL RR LL, sem pausa entre as mãos.</li></ul><h3>Diferença do Open Roll</h3><p>É o <strong>mesmo padrão</strong> (RR LL). No open roll cada nota fica bem separada; no double stroke roll você busca igualdade entre os golpes e pode acelerar.</p>`,
  24: `<p>O five stroke roll é RR LL R - cinco batidas no total.</p><p>É um dos rulos mais usados na bateria.</p><p>Aprenda a tocá-lo com fluidez.</p>`,
  25: `<p>O seven stroke roll é RR LL RR L - sete batidas no total.</p><p>Usado em fills e transições.</p><p>Exige controle de velocidade.</p>`,
  26: `<p>O nine stroke roll é RR LL RR LL R - nove batidas.</p><p>Comum em fills de rock e pop.</p><p>Pratique com metrônomo.</p>`,
  27: `<p>O ten stroke roll é RR LL RR LL RR - dez batidas.</p><p>Usado em fills mais longos.</p><p>Mantenha a equalidade entre mãos.</p>`,
  28: `<p>O eleven stroke roll é RR LL RR LL RR L - onze batidas.</p><p>Padrão mais complexo para fills.</p><p>Desenvolve resistência.</p>`,
  29: `<p>O thirteen stroke roll é RR LL RR LL RR LL R - treze batidas.</p><p>Usado em fills dramáticos.</p><p>Pratique em diferentes velocidades.</p>`,
  30: `<p>O fifteen stroke roll é RR LL RR LL RR LL RR L - quinze batidas.</p><p>O mais longo dos rulos básicos.</p><p>Domine antes de avançar.</p>`,
  31: `<p>Sincopação com pares combina duplos com acentos sincopados.</p><p>Cria grooves mais interessantes.</p><p>É essencial para funk e R&B.</p>`,
  32: `<p>Acentuar a segunda batida cria um efeito de 'empurrão'.</p><p>É usado em许多 estilos musicais.</p><p>Desenvolve independência.</p>`,
  33: `<p>Acentuar a terceira batida é comum em ballads.</p><p>Cria um efeito mais suave.</p><p>Pratique com diferentes dinâmicas.</p>`,
  34: `<p>Acentuar a quarta batida cria antecipação.</p><p>É usado antes de transições.</p><p>Desenvolve timing preciso.</p>`,
  35: `<p>Acentos duplos reforçam o ritmo.</p><p>É uma técnica poderosa para fills.</p><p>Mantenha a energia constante.</p>`,
  36: `<p>Acentos em tercinas criam fluidez.</p><p>É comum em jazz e fusion.</p><p>Pratique em diferentes compassos.</p>`,
  37: `<p>A sincopa de rock é a base de muitos grooves.</p><p>Padrão: <strong>R r R l R r R l</strong></p><p>É essencial para bateristas de rock.</p>`,
  38: `<p>O funk exige sincopação precisa.</p><p>Padrão: <strong>r R r l R r l R</strong></p><p>Desenvola seu groove.</p>`,
  39: `<p>A bossa nova tem um padrão suave e sincopado.</p><p>Padrão: <strong>R l r l R l r l</strong></p><p>É um dos estilos mais elegantes.</p>`,
  40: `<p>O samba é energético e sincopado.</p><p>Padrão: <strong>R r l R r l R r l R r l</strong></p><p>Celebre a cultura brasileira.</p>`,
  41: `<p>Grupos de 5 (quintupletas) criam efeito assimétrico.</p><p>Desenvolve coordenação avançada.</p><p>É usado em jazz e fusion.</p>`,
  42: `<p>Grupos de 7 (septupletas) são desafiadores.</p><p>Criam tensão e release na música.</p><p>Pratique lentamente.</p>`,
  43: `<p>Grupos de 9 são usados em fills complexos.</p><p>Exigem controle total das mãos.</p><p>Domine grupos menores primeiro.</p>`,
  44: `<p>Polirritmia 3x4 é tocar 3 notas no espaço de 4.</p><p>Cria um efeito circular e hipnótico.</p><p>É fundamental para jazz.</p>`,
  45: `<p>Polirritmia 4x3 é tocar 4 notas no espaço de 3.</p><p>Cria tensão e movimento.</p><p>Desenvolve independência rítmica.</p>`,
  46: `<p>Este exercício combina todos os conceitos anteriores.</p><p>Alternância, acentos, duplos e paradiddles.</p><p>É um teste completo de controle.</p>`,
  47: `<p>Padrão avançado com flams e paradiddles.</p><p>Exige fluidez e precisão.</p><p>Pratique até ficar natural.</p>`,
  48: `<p>Viradas são usadas para marcar transições.</p><p>Começamos com padrões simples de 4 e 8 batidas.</p><p>Mantenha o timing durante a virada.</p>`,
  49: `<p>Viradas avançadas usam ornamentos.</p><p>Flams e drags criam fills expressivos.</p><p>Controle a dinâmica.</p>`,
  50: `<p>Parabéns! Você completou o Stick Control.</p><p>Continue praticando diariamente.</p><p>Use o que aprendeu em músicas reais.</p>`,
  51: `<p>Os pés são a base do groove.</p><p>O <strong>bumo</strong> marca o pulso e o <strong>hi-hat</strong> controla a subdivisão.</p><p>Comece devagar e foque na equalidade das batidas.</p><p>Pratique o bumbo sozinho antes de combinar com o hi-hat.</p>`,
  52: `<p>A coordenação mãos+pés é o que separa um练习ador de um baterista.</p><p>O segredo é começar com padrões simples e ir adicionando complexidade gradualmente.</p><p>Use o metrônomo para manter tudo sincronizado.</p>`,
  53: `<p><strong>Dinâmica</strong> é o que dá vida à música.</p><p><strong>Crescendo</strong> = ficar mais forte gradualmente.</p><p><strong>Diminuendo</strong> = ficar mais suave.</p><p>Use a altura da batida: baixa = piano, alta = forte.</p>`,
  54: `<p>O segredo da velocidade é a <strong>paciência</strong>.</p><p>Aumente 5 BPM por vez. Se falhar, volte 5 BPM e treine mais.</p><p>A velocidade vem como consequência da técnica correta, nunca da força.</p><p>Punhos soltos = velocidade.</p>`,
  55: `<p>Chegou a hora de aplicar tudo!</p><p>O <strong>paradiddle</strong> vira um groove de rock.</p><p>Os <strong>duplos</strong> viram fills de transição.</p><p>Os <strong>acentos</strong> criam movimento e energia.</p>`,
  56: `<p>Ler partitura é como ler um livro — quanto mais praticar, mais fluido fica.</p><p>Comece identificando as <strong>notas pretas</strong> (quarter notes).</p><p>Depois avance para <strong>notas com rabo</strong> (eighth notes).</p><p>Pratique olhando a partitura e tocando sem parar.</p>`
};

// Diagram texts
const chapterDiagrams = {
  0: `<span class="right">    R</span>     <span class="left">L</span>\n   / \\\\     / \\\\\n  /   \\\\   /   \\\\\n <span class="right">Mão</span>  <span class="left">Mão</span>\n<span class="right">Direita</span> <span class="left">Esquerda</span>`,
  1: `   <span class="left">[Chimbal]</span>\n  /             \\\\\n<span class="right">[Tom Alto]</span>     <span class="left">[Tom Médio]</span>\n  \\\\             /\n   <span class="right">[Caixa]</span>\n      |\n   <span class="left">[Bumbo]</span>`,
  2: `Compasso 4/4:\n<span class="right">R</span>   <span class="left">L</span>   <span class="right">R</span>   <span class="left">L</span>\n♩     ♩     ♩     ♩\n1     2     3     4`,
  3: `<span class="right">R</span>   <span class="left">L</span>   <span class="right">R</span>   <span class="left">L</span>   <span class="right">R</span>   <span class="left">L</span>   <span class="right">R</span>   <span class="left">L</span>\n ↓     ↓     ↓     ↓     ↓     ↓     ↓     ↓\n1     2     3     4     1     2     3     4`,
  4: `<span class="right">R</span> <span class="right">R</span>   <span class="left">L</span> <span class="left">L</span>   <span class="right">R</span> <span class="right">R</span>   <span class="left">L</span> <span class="left">L</span>\n ↓   ↓     ↓   ↓     ↓   ↓     ↓   ↓\n1   &     2   &     3   &     4   &`
};

// Tips texts
const chapterTips = {
  0: `<div class="tip-box"><strong>💡 Dica:</strong> Comece sempre devagar. A velocidade vem com a prática consistente.</div>`,
  1: `<div class="tip-box"><strong>💡 Dica:</strong> Na partitura, cada nota representa um componente diferente da bateria.</div>`,
  2: `<div class="tip-box"><strong>💡 Dica:</strong> Conte em voz alta enquanto toca: "Um, dois, três, quatro..."</div><div class="warning-box"><strong>⚠️ Cuidado:</strong> Não confunda o compasso (4/4) com o BPM (velocidade).</div>`,
  3: `<div class="tip-box"><strong>💡 Dica:</strong> Mantenha os punhos soltos. A tensão é inimiga da velocidade.</div><div class="tip-box"><strong>💡 Dica:</strong> Use um metrônomo! Comece em 60 BPM e aumente 5 BPM por dia.</div>`,
  4: `<div class="tip-box"><strong>💡 Dica:</strong> Preste atenção para que ambas as mãos tenham a mesma intensidade.</div>`,
  5: `<div class="tip-box"><strong>💡 Dica:</strong> Minúsculas (r, l) = notas fracas. Maiúsculas (R, L) = notas fortes.</div>`,
  13: `<div class="tip-box"><strong>💡 Dica:</strong> O paradiddle é a base de centenas de padrões. Domine-o!</div>`,
  16: `<div class="tip-box"><strong>💡 Dica:</strong> O flam funciona melhor quando a mão menor está bem perto da membrana.</div>`,
  21: `<div class="tip-box"><strong>💡 Dica:</strong> O open roll é a base dos rulos em marchas e solos. Cada nota precisa ser audível!</div><div class="warning-box"><strong>⚠️ Cuidado:</strong> Se o 2º golpe soa 'embaçado', é porque você deixou quicar demais. Freie o rebote.</div>`,
  22: `<div class="tip-box"><strong>💡 Dica:</strong> O single stroke roll é o exercício mais básico de velocidade.</div>`,
  23: `<div class="tip-box"><strong>💡 Dica:</strong> No double stroke, cada nota deve ser claramente audível.</div>`,
  37: `<div class="tip-box"><strong>💡 Dica:</strong> A sincopa de rock é a base de muitos grooves famosos.</div>`,
  38: `<div class="tip-box"><strong>💡 Dica:</strong> O funk exige feeling. Não toque mecanicamente!</div>`,
  39: `<div class="tip-box"><strong>💡 Dica:</strong> A bossa nova é suave. Não force as batidas.</div>`,
  44: `<div class="tip-box"><strong>💡 Dica:</strong> Polirritmia é difícil no início. Use o metrônomo!</div>`,
  50: `<div class="tip-box"><strong>🎉 Parabéns!</strong> Você completou o Stick Control. Continue praticando!</div>`
};

// Default exercise for chapters
const defaultExercise = {
  exercise: ['R', 'L', 'R', 'L', 'R', 'L', 'R', 'L'],
  extra: null,
  weeklyGoal: [
    { day: 'Dia 1-3', bpm: 60, duration: '5 min' },
    { day: 'Dia 4-5', bpm: 70, duration: '8 min' },
    { day: 'Dia 6-7', bpm: 80, duration: '10 min' }
  ]
};

// Exercise map for each chapter (fallback if API fails)
const chapterExercises = {
  0: ['R', 'L', 'R', 'L', 'R', 'L', 'R', 'L'],
  1: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  2: ['R', 'R', 'L', 'R', 'L', 'L', 'R', 'L'],
  3: ['R', 'L', 'R', 'L', 'R', 'L', 'R', 'L'],
  4: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  5: ['R', 'l', 'r', 'l', 'R', 'l', 'r', 'l'],
  6: ['R', 'L', 'R', 'L', 'R', 'L', 'R', 'L', 'R', 'L'],
  7: ['R', 'l', 'r', 'l', 'R', 'l', 'r', 'l', 'R', 'l', 'r', 'l', 'R', 'l', 'r', 'l'],
  8: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  9: ['R', 'R', 'R', 'L', 'L', 'L', 'R', 'R', 'R', 'L', 'L', 'L'],
  10: ['R', 'R', 'R', 'R', 'L', 'L', 'L', 'L', 'R', 'R', 'R', 'R', 'L', 'L', 'L', 'L'],
  11: ['R', 'R', 'L', 'L', 'L', 'R', 'R', 'L', 'L', 'L', 'R', 'R', 'L', 'L', 'L'],
  12: ['R', 'l', 'r', 'l', 'r', 'l', 'R', 'l', 'r', 'l', 'r', 'l'],
  13: ['R', 'L', 'R', 'R', 'L', 'R', 'L', 'L'],
  14: ['R', 'L', 'R', 'L', 'R', 'R', 'L', 'R', 'L', 'R', 'L', 'L'],
  15: ['R', 'L', 'R', 'L', 'R', 'L', 'R', 'R', 'L', 'R', 'L', 'R', 'L', 'R', 'L', 'L'],
  16: ['R', 'L', 'R', 'L', 'R', 'L', 'R', 'L'],
  17: ['R', 'L', 'R', 'R', 'L', 'R', 'L', 'L'],
  18: ['r', 'r', 'R', 'l', 'r', 'r', 'L', 'r'],
  19: ['r', 'r', 'r', 'R', 'l', 'l', 'l', 'L'],
  20: ['R', 'R', 'R', 'R', 'R', 'R', 'L', 'L', 'L', 'L', 'L', 'L'],
  21: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  22: ['R', 'L', 'R', 'L', 'R', 'L', 'R', 'L'],
  23: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  24: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  25: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  26: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  27: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  28: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  29: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  30: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  31: ['R', 'R', 'l', 'l', 'R', 'R', 'l', 'l', 'R', 'R', 'l', 'l'],
  32: ['r', 'R', 'l', 'l', 'r', 'R', 'l', 'l'],
  33: ['r', 'l', 'R', 'l', 'r', 'l', 'R', 'l'],
  34: ['r', 'l', 'r', 'R', 'r', 'l', 'r', 'R'],
  35: ['R', 'r', 'l', 'l', 'R', 'r', 'l', 'l'],
  36: ['R', 'l', 'r', 'L', 'r', 'l', 'R', 'l'],
  37: ['R', 'r', 'R', 'l', 'R', 'r', 'R', 'l'],
  38: ['r', 'R', 'r', 'l', 'R', 'r', 'l', 'R'],
  39: ['R', 'l', 'r', 'l', 'R', 'l', 'r', 'l'],
  40: ['R', 'r', 'l', 'R', 'r', 'l', 'R', 'r', 'l', 'R', 'r', 'l'],
  41: ['R', 'l', 'r', 'l', 'r', 'R', 'l', 'r', 'l', 'r'],
  42: ['R', 'l', 'r', 'l', 'r', 'l', 'r', 'R', 'l', 'r', 'l', 'r', 'l', 'r'],
  43: ['R', 'l', 'r', 'l', 'r', 'l', 'r', 'l', 'r', 'R', 'l', 'r', 'l', 'r', 'l', 'r', 'l', 'r'],
  44: ['R', 'l', 'r', 'L', 'r', 'l', 'R', 'l', 'r', 'L', 'r', 'l'],
  45: ['R', 'l', 'r', 'l', 'L', 'r', 'l', 'r', 'R', 'l', 'r', 'l'],
  46: ['R', 'L', 'R', 'R', 'L', 'R', 'L', 'L', 'R', 'l', 'r', 'l', 'R', 'R', 'L', 'L'],
  47: ['R', 'L', 'R', 'R', 'L', 'R', 'L', 'L', 'R', 'l', 'r', 'l', 'R', 'r', 'L', 'l'],
  48: ['R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  49: ['R', 'L', 'R', 'R', 'L', 'R', 'L', 'L', 'R', 'L', 'R', 'R', 'L', 'R', 'L', 'L'],
  50: ['R', 'L', 'R', 'L', 'R', 'R', 'L', 'L', 'R', 'L', 'R', 'R', 'L', 'R', 'L', 'L'],
  51: ['R', '-', 'R', '-', 'R', '-', 'R', '-', 'R', '-', 'r', '-', 'R', '-', 'r', '-'],
  52: ['R', 'L', 'R', 'L', 'R', 'L', 'R', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  53: ['r', 'l', 'r', 'l', 'R', 'L', 'R', 'L', 'R', 'L', 'R', 'L', 'R', 'L', 'R', 'L'],
  54: ['R', 'L', 'R', 'L', 'R', 'L', 'R', 'L', 'R', 'R', 'L', 'L', 'R', 'R', 'L', 'L'],
  55: ['R', 'l', 'R', 'l', 'R', 'l', 'r', 'l', 'R', 'L', 'R', 'R', 'L', 'R', 'L', 'L'],
  56: ['R', 'L', '-', 'L', 'R', '-', 'R', 'L', 'R', '-', 'L', 'R', '-', 'R', '-', 'L']
};

// Fetch chapter data from API
async function fetchChapterData(chapterId) {
  try {
    const token = localStorage.getItem('token');
    const response = await fetch(`/api/chapters/${chapterId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (response.ok) {
      return await response.json();
    }
  } catch (e) {
    console.log('Fetching from API failed, using defaults');
  }
  return null;
}

// Get current exercise data
async function getCurrentExerciseData() {
  const apiData = await fetchChapterData(currentChapterId);
  
  // Priority: API data > hardcoded fallbacks
  const title = (apiData && apiData.title) || chapterTitles[currentChapterId] || `Capítulo ${currentChapterId + 1}`;
  const concept = (apiData && apiData.concept) || chapterConcepts[currentChapterId] || `<p>Pratique este exercício consistentemente.</p>`;
  const diagram = (apiData && apiData.diagram) || chapterDiagrams[currentChapterId] || `<span class="right">R</span> <span class="left">L</span> <span class="right">R</span> <span class="left">L</span>`;
  const tips = (apiData && apiData.tips) || chapterTips[currentChapterId] || `<div class="tip-box"><strong>💡 Dica:</strong> Pratique todos os dias!</div>`;
  
  // Priority: API data > chapterExercises map > default
  let exercise = chapterExercises[currentChapterId] || defaultExercise.exercise;
  if (apiData && apiData.exercise) {
    exercise = apiData.exercise;
  }
  
  let objectives = apiData && apiData.objectives ? apiData.objectives : ["Continuar praticando os conceitos anteriores"];
  let weeklyGoal = defaultExercise.weeklyGoal;
  if (apiData && apiData.weeklyGoal) {
    const wg = apiData.weeklyGoal;
    if (Array.isArray(wg)) {
      weeklyGoal = wg;
    } else if (wg && wg.targetBpm) {
      weeklyGoal = [
        { day: 'Dia 1-3', bpm: wg.targetBpm, duration: `${wg.minutesPerDay || 5} min` },
        { day: 'Dia 4-5', bpm: Math.round(wg.targetBpm * 1.1), duration: `${Math.round((wg.minutesPerDay || 5) * 1.5)} min` },
        { day: 'Dia 6-7', bpm: Math.round(wg.targetBpm * 1.2), duration: `${wg.minutesPerDay || 5} min` }
      ];
    }
  }
  
  return {
    title: title,
    subtitle: currentChapterId >= 100
      ? `Módulo Preparatório — Aula ${currentChapterId - 99} de 9`
      : `Módulo 1 — Capítulo ${currentChapterId + 1} de 57`,
    objectives: objectives,
    concept: concept,
    diagram: diagram,
    tips: tips,
    exercise: exercise,
    extra: null,
    weeklyGoal: weeklyGoal
  };
}

// Check if current chapter is locked
async function isChapterLocked() {
  // Preparatory module: 100-108
  if (currentChapterId >= 100 && currentChapterId <= 108) {
    if (currentChapterId === 100) return false;
  }
  // Main module: chapter 0 requires prep module complete
  if (currentChapterId === 0) {
    const token = localStorage.getItem('token');
    if (!token) return true;
    try {
      const response = await fetch('/api/progress', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      cachedProgress = await response.json();
      return !cachedProgress.some(p => p.chapter_id === 108 && p.completed);
    } catch (e) { return true; }
  }
  
  if (currentChapterId < 100 && currentChapterId > 0) {
    // Main module: check previous chapter
  } else if (currentChapterId > 100) {
    // Prep module: check previous prep chapter
  } else {
    return false;
  }
  
  const token = localStorage.getItem('token');
  if (!token) return true;
  
  try {
    const response = await fetch('/api/progress', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    cachedProgress = await response.json();
    const prevCompleted = cachedProgress.some(p => p.chapter_id === currentChapterId - 1 && p.completed);
    return !prevCompleted;
  } catch (e) {
    return true;
  }
}

// Get current exercise array (for audio) - uses chapterDataCache if available
function getCurrentExercise() {
  if (chapterDataCache && chapterDataCache.exercise) {
    return chapterDataCache.exercise;
  }
  return chapterExercises[currentChapterId] || defaultExercise.exercise;
}

// Render partitura
function renderPartitura(exercise) {
  const container = document.getElementById('partitura');
  const ts = typeof timeSignature !== 'undefined' ? timeSignature : 4;
  const notesPerBeat = typeof audioEngine !== 'undefined' ? audioEngine.notesPerBeat : 2;
  const notesPerMeasure = ts * notesPerBeat;
  
  let html = '';
  for (let m = 0; m < exercise.length; m += notesPerMeasure) {
    if (m > 0) html += '<span class="barline"></span>';
      html += '<span class="measure">';
    html += '<span class="notes-row">';
    for (let b = 0; b < notesPerMeasure && m + b < exercise.length; b++) {
      const i = m + b;
      const note = exercise[i];
      
      // Beat separator (every 4 notes)
      if (b > 0 && b % notesPerBeat === 0) {
        html += '<span class="beat-sep"></span>';
      }
      
    let className = 'nota';
    if (note === 'R' || note === 'r') {
      className += ' right';
    } else if (note === 'L' || note === 'l') {
      className += ' left';
    } else if (note === 'B' || note === 'b') {
      className += ' accent';
    }
    
    if (note === note.toLowerCase() && note !== '-' && note !== ' ') {
      className += ' soft';
    }
    
    let display = note;
    // Compound notes (flam "rR", drag "rrL", ruff "rrrL", buzz "RRRR"...):
    // render each hand as its own sub-note so it doesn't read like "RR LL"
    if (note.length > 1 && note !== '>' && note !== '!') {
      className = 'nota';
      const mainChar = note[note.length - 1];
      if (mainChar === 'R' || mainChar === 'r') className += ' right';
      else if (mainChar === 'L' || mainChar === 'l') className += ' left';
      else if (mainChar === 'B' || mainChar === 'b') className += ' accent';
      if (mainChar === mainChar.toLowerCase() && mainChar !== '-' && mainChar !== ' ') className += ' soft';
      display = note.split('').map(ch => {
        let c = 'flam-grace';
        if (ch === 'R' || ch === 'r') c += ' right';
        else if (ch === 'L' || ch === 'l') c += ' left';
        else if (ch === 'B' || ch === 'b') c += ' accent';
        if (ch === ch.toLowerCase() && ch !== '-' && ch !== ' ') c += ' soft';
        return `<span class="${c}">${ch}</span>`;
      }).join('');
    }
    
    html += `<span class="note-wrapper"><span class="${className}" data-index="${i}">${display}</span></span>`;
    }
    html += '</span>'; // end notes-row
    
    // Beat numbers below the measure
    html += '<span class="beat-labels-row">';
    for (let beat = 0; beat < ts; beat++) {
      html += `<span class="beat-indicator ${beat === 0 ? 'accent-beat' : ''}"></span>`;
    }
    html += '</span>';
    html += '</span>';
  }
  
  container.innerHTML = html;
}

// Render weekly goal
let currentWeeklyGoalData = null;

function renderWeeklyGoal(goal) {
  const container = document.getElementById('goal-items');
  currentWeeklyGoalData = goal || [];
  
  if (!goal || goal.length === 0) {
    container.innerHTML = '<p style="color: var(--text-secondary);">Defina suas metas semanais</p>';
    return;
  }
  
  container.innerHTML = `
    <p class="goal-hint">Sugestão semanal — clique em <strong>Aplicar</strong> para carregar no metrônomo. Muito rápido? Diminua o BPM.</p>
  ` + goal.map((item, i) => `
    <div class="goal-item" onclick="applyWeeklyGoal(${i})" title="Aplicar no metrônomo">
      <span class="day">${item.day}</span>
      <span class="bpm">${item.bpm} BPM</span>
      <span class="duration">${item.duration}</span>
      <button class="goal-apply-btn" onclick="event.stopPropagation();applyWeeklyGoal(${i})">Aplicar</button>
    </div>
  `).join('');
}

function parseDurationMinutes(dur) {
  if (!dur) return null;
  const m = String(dur).match(/(\d+)/);
  return m ? parseInt(m[1]) : null;
}

function getGoalForToday(goal) {
  if (!goal || goal.length === 0) return null;
  const today = new Date().getDay() + 1; // Dom=1, Seg=2 ... Sáb=7 (week starts Sunday)
  for (let i = 0; i < goal.length; i++) {
    const m = String(goal[i].day || '').match(/(\d+)\s*[-–]\s*(\d+)/);
    if (m) {
      const s = parseInt(m[1]);
      const e = parseInt(m[2]);
      if (today >= s && today <= e) return goal[i];
    }
  }
  return goal[0];
}

function setTimerFromMinutes(mins) {
  const input = document.getElementById('timer-minutes');
  if (mins && input) {
    input.value = mins;
    if (typeof timerTotalSeconds !== 'undefined') {
      timerTotalSeconds = mins * 60;
      timerSeconds = timerTotalSeconds;
      if (typeof updateTimerDisplay === 'function') updateTimerDisplay();
    }
  }
}

function applyWeeklyGoal(index) {
  if (!currentWeeklyGoalData || !currentWeeklyGoalData[index]) return;
  const item = currentWeeklyGoalData[index];
  if (item.bpm && typeof setBPM === 'function') setBPM(item.bpm);
  setTimerFromMinutes(parseDurationMinutes(item.duration));
  showToast('🎯 Meta aplicada: ' + item.bpm + ' BPM / ' + item.duration + '. Muito rápido? Diminua o BPM.');
  const items = document.querySelectorAll('.goal-item');
  if (items[index]) {
    items[index].classList.remove('goal-flash');
    void items[index].offsetWidth;
    items[index].classList.add('goal-flash');
  }
}

// Auto-applies today's goal to the metronome (BPM + timer) on first visit
function applyWeeklyGoalSuggestion(goal) {
  if (!goal || goal.length === 0) return;
  if (typeof currentChapterId === 'undefined') return;
  const savedBpm = parseInt(localStorage.getItem('bpmCh_' + currentChapterId), 10);
  if (!isNaN(savedBpm) && savedBpm >= 40) return; // já tem BPM próprio → não sobrescrever
  const item = getGoalForToday(goal);
  if (!item) return;
  if (item.bpm && typeof setBPM === 'function') setBPM(item.bpm);
  setTimerFromMinutes(parseDurationMinutes(item.duration));
}

function showToast(msg) {
  let toast = document.getElementById('app-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'app-toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toast._hide);
  toast._hide = setTimeout(() => toast.classList.remove('show'), 3500);
}

// Load chapter
async function loadChapter() {
  // Check if chapter is locked
  const locked = await isChapterLocked();
  
  if (locked) {
    document.getElementById('chapter-title').textContent = 'Capítulo Trancado';
    document.getElementById('chapter-subtitle').textContent = 'Complete o capítulo anterior para desbloquear';
    document.getElementById('objectives').innerHTML = '<p style="color: var(--text-secondary);">Você precisa completar o capítulo anterior primeiro.</p>';
    document.getElementById('concept').innerHTML = '';
    document.getElementById('diagram').innerHTML = '<p style="color: var(--text-secondary);">🔒</p>';
    document.getElementById('tips').innerHTML = '<div class="warning-box"><strong>⚠️ Bloqueado:</strong> Volte ao dashboard e complete o capítulo anterior.</div>';
    document.getElementById('partitura').innerHTML = '<p style="color: var(--text-secondary);">Capítulo trancado</p>';
    document.getElementById('goal-items').innerHTML = '';
    document.getElementById('complete-btn').disabled = true;
    document.getElementById('complete-btn').style.opacity = '0.5';
    return;
  }
  
  const data = await getCurrentExerciseData();
  chapterDataCache = data;
  
  document.getElementById('chapter-title').textContent = data.title;
  document.getElementById('chapter-subtitle').textContent = data.subtitle;
  document.getElementById('objectives').innerHTML = `
    <ul>${data.objectives.map(o => `<li>${o}</li>`).join('')}</ul>
  `;
  document.getElementById('concept').innerHTML = data.concept;
  document.getElementById('diagram').innerHTML = data.diagram;
  document.getElementById('tips').innerHTML = data.tips;
  
  // Extra exercise
  if (data.extra) {
    document.getElementById('extra-exercise').style.display = 'block';
    document.getElementById('extra-content').innerHTML = data.extra.content;
  }
  
  // Partitura
  renderPartitura(data.exercise);
  
  // Weekly goal
  renderWeeklyGoal(data.weeklyGoal);
  
  // Restore last BPM used for this chapter
  var savedBpm = parseInt(localStorage.getItem('bpmCh_' + currentChapterId), 10);
  if (savedBpm >= 40 && typeof setBPM === 'function') {
    setBPM(savedBpm);
  } else {
    // First time: auto-apply today's goal (BPM + timer) to the metronome
    applyWeeklyGoalSuggestion(data.weeklyGoal);
  }
  
  // Load and display progress for this chapter
  await loadChapterProgress();
  
  // Update navigation
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  if (currentChapterId === 100 || currentChapterId === 0) {
    prevBtn.style.visibility = 'hidden';
  } else {
    prevBtn.style.visibility = 'visible';
  }
  if ((currentChapterId >= 100 && currentChapterId < 108) || (currentChapterId < 56 && currentChapterId >= 0)) {
    nextBtn.style.visibility = 'visible';
  } else if (currentChapterId === 56 || currentChapterId === 108) {
    nextBtn.style.visibility = 'hidden';
  }
}

// Load progress for current chapter
async function loadChapterProgress() {
  if (cachedProgress) {
    const chapterProgress = cachedProgress.find(p => p.chapter_id === currentChapterId);
    updateChapterProgressUI(chapterProgress);
    cachedProgress = null;
    return;
  }
  
  const token = localStorage.getItem('token');
  if (!token) return;
  
  try {
    const response = await fetch('/api/progress', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const progress = await response.json();
    const chapterProgress = progress.find(p => p.chapter_id === currentChapterId);
    updateChapterProgressUI(chapterProgress);
  } catch (error) {
    console.error('Erro ao carregar progresso:', error);
    document.getElementById('detail-status').textContent = 'Erro ao carregar';
  }
}

function updateChapterProgressUI(chapterProgress) {
    
    if (chapterProgress) {
      // Update progress bar
      const percent = chapterProgress.completed ? 100 : Math.min(90, (chapterProgress.max_bpm / 120) * 100);
      document.getElementById('chapter-progress').textContent = `${Math.round(percent)}%`;
      document.getElementById('chapter-progress-bar').style.width = `${percent}%`;
      
      // Update progress details
      document.getElementById('detail-bpm').textContent = chapterProgress.max_bpm || '-';
      document.getElementById('detail-time').textContent = formatPracticeTime(chapterProgress.practice_time || 0);
      document.getElementById('detail-status').textContent = chapterProgress.completed ? '✓ Completo' : 'Em andamento';
      
      // Update complete button if already completed
      if (chapterProgress.completed) {
        document.getElementById('complete-btn').textContent = '✓ Completo!';
        document.getElementById('complete-btn').style.background = 'var(--success)';
      }
    } else {
      // No progress yet
      document.getElementById('chapter-progress').textContent = '0%';
      document.getElementById('chapter-progress-bar').style.width = '0%';
      document.getElementById('detail-bpm').textContent = '-';
      document.getElementById('detail-time').textContent = '-';
      document.getElementById('detail-status').textContent = 'Não iniciado';
    }
}

// Format practice time
function formatPracticeTime(seconds) {
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}min`;
  return `${Math.round(seconds / 3600)}h`;
}

// Navigation
function prevChapter() {
  if (currentChapterId >= 100 && currentChapterId > 100) {
    currentChapterId--;
    window.location.href = `/curso?cap=${currentChapterId}`;
  } else if (currentChapterId === 100) {
    window.location.href = '/dashboard';
  } else if (currentChapterId > 0) {
    currentChapterId--;
    window.location.href = `/curso?cap=${currentChapterId}`;
  }
}

function nextChapter() {
  if (currentChapterId >= 100 && currentChapterId < 108) {
    currentChapterId++;
    window.location.href = `/curso?cap=${currentChapterId}`;
  } else if (currentChapterId === 108) {
    window.location.href = `/curso?cap=0`;
  } else if (currentChapterId < 56) {
    currentChapterId++;
    window.location.href = `/curso?cap=${currentChapterId}`;
  }
}

// Mark as complete
async function markComplete() {
  const token = localStorage.getItem('token');
  if (!token) return;
  
  // Send delta practice time (not total) to avoid double-counting
  const practiceTime = (typeof getPracticeTime === 'function' ? getPracticeTime() : 0) - (typeof lastSavedPracticeTime !== 'undefined' ? lastSavedPracticeTime : 0);
  const maxBpm = typeof getMaxBpm === 'function' ? getMaxBpm() : bpm;
  
  try {
    await fetch('/api/progress', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        chapterId: currentChapterId,
        completed: true,
        maxBpm: maxBpm,
        practiceTime: practiceTime
      })
    });
    
    document.getElementById('complete-btn').textContent = '✓ Completo!';
    document.getElementById('complete-btn').style.background = 'var(--success)';
    
    // Update last saved time to avoid double-counting on next save
    lastSavedPracticeTime = practiceTimeAccumulated;
    
    // Golden burst effect
    if (typeof window.triggerBurst === 'function') {
      const btn = document.getElementById('complete-btn');
      const rect = btn.getBoundingClientRect();
      window.triggerBurst(rect.left + rect.width / 2, rect.top + rect.height / 2, 50);
    }
    
    // Refresh progress display
    await loadChapterProgress();
    
    // Check achievements
    await checkAchievements();
    
  } catch (error) {
    console.error('Error saving progress:', error);
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  // Save current chapter for next login redirect
  if (typeof currentChapterId !== 'undefined' && currentChapterId !== null) {
    localStorage.setItem('lastChapter', currentChapterId);
  }
  
  loadChapter();
  
  // Save progress when leaving page using keepalive fetch (reliable even during unload)
  window.addEventListener('beforeunload', () => {
    if (typeof practiceTimeAccumulated !== 'undefined' && typeof lastSavedPracticeTime !== 'undefined') {
      const delta = practiceTimeAccumulated - lastSavedPracticeTime;
      if (delta > 0) {
        const token = localStorage.getItem('token');
        if (token && typeof currentChapterId !== 'undefined') {
          fetch('/api/progress', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
              chapterId: currentChapterId,
              completed: false,
              maxBpm: Math.max(maxBpmAchieved, bpm),
              practiceTime: delta
            }),
            keepalive: true
          }).catch(() => {});
        }
      }
    }
  });
});

// ============ ACHIEVEMENTS ============

async function checkAchievements() {
  const token = localStorage.getItem('token');
  if (!token) return;
  try {
    const res = await fetch('/api/achievements/check', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
    const data = await res.json();
    if (data.new && data.new.length > 0) {
      // Show popup for each new achievement
      data.new.forEach((ach, i) => {
        setTimeout(() => showAchievementPopup(ach), i * 2000);
      });
    }
  } catch(e) {}
}

function showAchievementPopup(ach) {
  const overlay = document.createElement('div');
  overlay.className = 'ach-popup-overlay show';
  overlay.innerHTML = `
    <div class="ach-popup">
      <div class="ach-popup-icon">${ach.icon}</div>
      <h2>${ach.name}</h2>
      <p>${ach.desc}</p>
      <button onclick="this.closest('.ach-popup-overlay').remove()">Fechar</button>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) overlay.remove();
  });
}
